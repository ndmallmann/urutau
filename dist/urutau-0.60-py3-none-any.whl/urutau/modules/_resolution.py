"""
    Spectra resolution modifier for Urutau.
"""
